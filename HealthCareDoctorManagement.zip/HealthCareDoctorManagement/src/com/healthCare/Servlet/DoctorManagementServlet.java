package com.healthCare.Servlet;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.FormParam;
import javax.ws.rs.GET;
import javax.ws.rs.HeaderParam;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import org.json.JSONArray;

import com.healthCare.Service.DoctorManageService;
import com.healthCare.model.*;

@Path("/doctor")
public class DoctorManagementServlet {

	DoctorManageService DoctorServiceObj = (DoctorManageService) new DoctorManagementServlet();

	@POST
	@Path("/registerUser")
	@Consumes(MediaType.APPLICATION_FORM_URLENCODED)
	@Produces(MediaType.TEXT_PLAIN)
	public Response registerUser(@FormParam("firstName") String firstName, @FormParam("lastName") String lastName,
			@FormParam("idnum") String idnum, @FormParam("gender") String gender, @FormParam("address") String address,
			@FormParam("mobileNumber") String mobileNumber, @FormParam("workplace") String workplace,
			@FormParam("degree") String degree, @FormParam("email") String email,
			@FormParam("password") String password, @HeaderParam("authString") String authString) {

		if (AccessFilter.checkAccess(new String[] { "doctor", "admin" }, authString)) {
			HashMap<String, String> h = DoctorServiceObj.RegisterUser(firstName, lastName, idnum, gender, address,
					mobileNumber, workplace, degree, email, password);

			if (h.get("register").equalsIgnoreCase("successfully")) {
				return Response.ok("successfully").build();
			} else {
				return Response.ok("failed").build();
			}
		} else {
			return Response.ok("You're Not Authorized").build();
		}
	}

	@POST
	@Path("/getUserDetails")
	@Consumes(MediaType.APPLICATION_FORM_URLENCODED)
	@Produces(MediaType.APPLICATION_JSON)
	public Response getUserDetails(@FormParam("userId") String Did, @HeaderParam("authString") String authString) {

		if (AccessFilter.checkAccess(new String[] { "patient", "admin" }, authString)) {
			DoctorUser user = DoctorServiceObj.getUserDetails(Did);
			return Response.ok("Hello").build();
		} else {
			return com.healthCare.model.Response.sendErrorResponse();
		}
	}

	@GET
	@Path("/getAllUsers")
	@Produces(MediaType.APPLICATION_JSON)
	public Response getAllUsers(@HeaderParam("authString") String authString) {
		if (AccessFilter.checkAccess(new String[] { "admin" }, authString)) {
			List<DoctorUser> userList = DoctorServiceObj.getAllUsers();
			JSONArray jsonArray = new JSONArray(userList);
			return Response.ok(jsonArray.toString()).build();
		} else {
			return com.healthCare.model.Response.sendErrorResponse();
		}
	}

	@DELETE
	@Path("/deleteUser")
	@Consumes(MediaType.APPLICATION_FORM_URLENCODED)
	@Produces(MediaType.APPLICATION_JSON)
	public Response deleteUser(@FormParam("userId") String Did, @HeaderParam("authString") String authString) {
		if (AccessFilter.checkAccess(new String[] { "patient", "admin" }, authString)) {
			DoctorUser user = DoctorServiceObj.deleteUser(Did);
			return Response.ok(user).build();
		} else {
			return com.healthCare.model.Response.sendErrorResponse();
		}
	}

	@PUT
	@Path("/updateUser")
	@Consumes(MediaType.APPLICATION_FORM_URLENCODED)
	@Produces(MediaType.APPLICATION_JSON)
	public Response updateUser(@FormParam("userId") String Did, @FormParam("firstName") String firstName,
			@FormParam("lastName") String lastName, @FormParam("idnum") String idnum,
			@FormParam("gender") String gender, @FormParam("address") String address,
			@FormParam("mobileNumber") String mobileNumber, @FormParam("workplace") String workplace,
			@FormParam("degree") String degree, @FormParam("email") String email,
			@HeaderParam("authString") String authString) {
		if (AccessFilter.checkAccess(new String[] { "patient", "admin" }, authString)) {
			DoctorUser user = DoctorServiceObj.updateUser(Did, firstName, lastName, idnum, gender, address,
					mobileNumber, workplace, degree, email);
			return Response.ok(user).build();
		} else {
			return com.healthCare.model.Response.sendErrorResponse();
		}
	}
}
